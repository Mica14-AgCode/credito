"use client"

import { useEffect, useState } from "react"

interface MapaGeoJSONProps {
  coordenadasPropios: string
  coordenadasAlquilados: string
  centroidePropiosLat: number
  centroidePropiosLng: number
  centroideAlquiladosLat: number
  centroideAlquiladosLng: number
  razonSocial: string
  cuit: string
  polygonFilter: string
}

// ──────────────────────────────────────────────────────────
// Convierte una celda CSV en un array de objetos válidos
function parseGeoJsonCell(cell: string): any[] {
  // Normalizar y descartar valores vacíos o de tipo "N/D"
  const trimmed = (cell ?? "").trim()
  if (
    !trimmed || // cadena vacía
    trimmed.toUpperCase() === "N/D" || // marcador "No Disponible"
    trimmed.toUpperCase() === "ND" // variación corta
  ) {
    return []
  }

  // Si la celda no empieza con "{" o "[" asumimos que NO es JSON
  // (evita intentar parsear textos como rutas de archivo, etc.).
  const firstChar = trimmed[0]
  if (firstChar !== "{" && firstChar !== "[") {
    return []
  }

  // 1) Limpieza básica
  let cleaned = trimmed
    .replace(/\\"/g, '"') // \"  -> "
    .replace(/\\n/g, "") // quita saltos escapados
    .replace(/\uFEFF/g, "") // quita BOM
    .trim()

  // 2) Primer intento: JSON válido
  try {
    return JSON.parse(cleaned)
  } catch (_) {
    /* vazio – intentaremos reparar */
  }

  // 3) Intento de reparación:
  //    a) comillas simples → dobles
  //    b) agrega comillas a las claves sin comillas  {tipo: ...} -> {"tipo": ...}
  cleaned = cleaned.replace(/'/g, '"').replace(/([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)\s*:/g, '$1"$2":')

  // c) agrega comillas a los valores string sin comillas  : Polygon → : "Polygon"
  cleaned = cleaned.replace(/:\s*([A-Za-z_][A-Za-z0-9_]*)\s*([,}])/g, (_m, val, tail) => {
    const lower = val.toLowerCase()
    // deja pasar true, false, null y números
    if (["true", "false", "null"].includes(lower) || /^\d+(\.\d+)?$/.test(val)) {
      return `: ${val}${tail}`
    }
    return `: "${val}"${tail}`
  })

  try {
    return JSON.parse(cleaned)
  } catch (err) {
    console.error("GeoJSON malformado irreparable:", err, cleaned.slice(0, 120) + "…")
    return []
  }
}

// Función para generar KML
function generateKML(polygons: any[], type: string, razonSocial: string, cuit: string): string {
  if (!polygons || polygons.length === 0) {
    console.warn(`No hay polígonos para generar KML de tipo: ${type}`)
    return ""
  }

  const kmlHeader = `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>${razonSocial} - ${type}</name>
    <description>Propiedades ${type} de ${razonSocial} (CUIT: ${cuit})</description>`

  const kmlFooter = `  </Document>
</kml>`

  const placemarks = polygons
    .map((polygon, index) => {
      if (!polygon.coordenadas || !Array.isArray(polygon.coordenadas)) {
        console.warn(`Polígono ${index} no tiene coordenadas válidas`)
        return ""
      }

      const coordinates = polygon.coordenadas
        .map((coord: number[]) => {
          if (!Array.isArray(coord) || coord.length < 2) return ""
          return `${coord[0]},${coord[1]},0`
        })
        .filter(Boolean)
        .join(" ")

      if (!coordinates) {
        console.warn(`Polígono ${index} no tiene coordenadas procesables`)
        return ""
      }

      return `    <Placemark>
      <name>${type} ${index + 1}</name>
      <description>Polígono ${index + 1} - ${type} - ${razonSocial}</description>
      <Polygon>
        <outerBoundaryIs>
          <LinearRing>
            <coordinates>${coordinates}</coordinates>
          </LinearRing>
        </outerBoundaryIs>
      </Polygon>
    </Placemark>`
    })
    .filter(Boolean)
    .join("\n")

  return `${kmlHeader}\n${placemarks}\n${kmlFooter}`
}

// Función para descargar archivo
function downloadFile(content: string, filename: string, mimeType: string) {
  if (!content) {
    console.error("No hay contenido para descargar")
    return false
  }

  try {
    // Método 1: Crear enlace de descarga y hacer click automático
    const blob = new Blob([content], { type: mimeType })
    const url = URL.createObjectURL(blob)

    // Crear elemento <a> temporal
    const link = document.createElement("a")
    link.href = url
    link.download = filename
    link.style.display = "none"

    // Agregar al DOM, hacer click y remover
    document.body.appendChild(link)

    // Forzar el click con diferentes métodos para compatibilidad
    if (link.click) {
      link.click()
    } else if (link.dispatchEvent) {
      const event = new MouseEvent("click", {
        view: window,
        bubbles: true,
        cancelable: true,
      })
      link.dispatchEvent(event)
    }

    // Cleanup después de un pequeño delay
    setTimeout(() => {
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    }, 100)

    console.log(`✅ Descarga iniciada: ${filename}`)
    return true
  } catch (error) {
    console.error("Error al descargar archivo:", error)

    // Método alternativo: Abrir en nueva ventana
    try {
      const blob = new Blob([content], { type: mimeType })
      const url = URL.createObjectURL(blob)
      const newWindow = window.open(url, "_blank")

      if (newWindow) {
        // Si se abre la ventana, programar descarga
        setTimeout(() => {
          newWindow.location.href = url
          newWindow.close()
          URL.revokeObjectURL(url)
        }, 1000)
        return true
      }
    } catch (fallbackError) {
      console.error("Error en método alternativo:", fallbackError)
    }

    return false
  }
}

export default function MapaGeoJSON({
  coordenadasPropios,
  coordenadasAlquilados,
  centroidePropiosLat,
  centroidePropiosLng,
  centroideAlquiladosLat,
  centroideAlquiladosLng,
  razonSocial,
  cuit,
  polygonFilter,
}: MapaGeoJSONProps) {
  const [mapLoaded, setMapLoaded] = useState(false)
  const [leaflet, setLeaflet] = useState<any>(null)
  const [map, setMap] = useState<any>(null)
  const [propiosLayers, setPropiosLayers] = useState<any[]>([])
  const [alquiladosLayers, setAlquiladosLayers] = useState<any[]>([])

  // Datos parseados
  const propiosData = parseGeoJsonCell(coordenadasPropios)
  const alquiladosData = parseGeoJsonCell(coordenadasAlquilados)

  console.log("📊 Datos parseados:", {
    propios: propiosData.length,
    alquilados: alquiladosData.length,
  })

  useEffect(() => {
    // Cargar Leaflet dinámicamente solo en el cliente
    const loadLeaflet = async () => {
      try {
        const L = await import("leaflet")
        await import("leaflet/dist/leaflet.css")

        // Fix para los iconos de Leaflet
        delete (L.Icon.Default.prototype as any)._getIconUrl
        L.Icon.Default.mergeOptions({
          iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
          iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
          shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
        })

        setLeaflet(L)
        setMapLoaded(true)
      } catch (error) {
        console.error("Error cargando Leaflet:", error)
      }
    }

    if (typeof window !== "undefined") {
      loadLeaflet()
    }
  }, [])

  useEffect(() => {
    if (!mapLoaded || !leaflet) return

    // Calcular centro del mapa basado en centroides
    const centerLat = (centroidePropiosLat + centroideAlquiladosLat) / 2
    const centerLng = (centroidePropiosLng + centroideAlquiladosLng) / 2

    // Crear el mapa
    const mapInstance = leaflet.map("mapa-geojson").setView([centerLat, centerLng], 10)

    // Definir capas base con nombres claros y estilos
    const osmLayer = leaflet.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors",
    })

    const satelliteLayer = leaflet.tileLayer(
      "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      {
        attribution: "© Esri, Maxar, Earthstar Geographics",
      },
    )

    const hybridLayer = leaflet.layerGroup([
      satelliteLayer,
      leaflet.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
        {
          attribution: "© Esri",
        },
      ),
    ])

    // Agregar capa base inicial
    osmLayer.addTo(mapInstance)

    // Crear polígonos propios
    const propiosLayersArray: any[] = []
    propiosData.forEach((poligono: any, index: number) => {
      if (poligono.coordenadas && poligono.coordenadas.length > 0) {
        const leafletCoords = poligono.coordenadas.map((coord: number[]) => [coord[1], coord[0]])

        const layer = leaflet
          .polygon(leafletCoords, {
            fillColor: "#22c55e",
            weight: 2,
            opacity: 1,
            color: "#16a34a",
            dashArray: "3",
            fillOpacity: 0.4,
          })
          .bindPopup(`
              <strong>Propiedad Propia ${index + 1}</strong><br/>
              <strong>${razonSocial}</strong><br/>
              Tipo: Propia<br/>
              Polígono: ${index + 1}
            `)

        layer.addTo(mapInstance)
        propiosLayersArray.push(layer)
      }
    })

    // Crear polígonos alquilados
    const alquiladosLayersArray: any[] = []
    alquiladosData.forEach((poligono: any, index: number) => {
      if (poligono.coordenadas && poligono.coordenadas.length > 0) {
        const leafletCoords = poligono.coordenadas.map((coord: number[]) => [coord[1], coord[0]])

        const layer = leaflet
          .polygon(leafletCoords, {
            fillColor: "#f97316",
            weight: 2,
            opacity: 1,
            color: "#ea580c",
            dashArray: "3",
            fillOpacity: 0.4,
          })
          .bindPopup(`
              <strong>Propiedad Alquilada ${index + 1}</strong><br/>
              <strong>${razonSocial}</strong><br/>
              Tipo: Alquilada<br/>
              Polígono: ${index + 1}
            `)

        layer.addTo(mapInstance)
        alquiladosLayersArray.push(layer)
      }
    })

    // Ajustar vista a todos los polígonos
    const allLayers = [...propiosLayersArray, ...alquiladosLayersArray]
    if (allLayers.length > 0) {
      const group = leaflet.featureGroup(allLayers)
      mapInstance.fitBounds(group.getBounds().pad(0.1))
    }

    // Crear control de capas personalizado con iconos
    const baseLayers = {
      "🗺️ Mapa Estándar": osmLayer,
      "🛰️ Vista Satelital": satelliteLayer,
      "🌍 Vista Híbrida": hybridLayer,
    }

    const layerControl = leaflet.control.layers(
      baseLayers,
      {},
      {
        position: "topright",
        collapsed: false,
      },
    )
    layerControl.addTo(mapInstance)

    // Personalizar el estilo del control de capas
    setTimeout(() => {
      const layerControlElement = layerControl.getContainer()
      if (layerControlElement) {
        layerControlElement.style.background = "rgba(255, 255, 255, 0.95)"
        layerControlElement.style.border = "2px solid #ccc"
        layerControlElement.style.borderRadius = "8px"
        layerControlElement.style.padding = "10px"
        layerControlElement.style.fontSize = "14px"
        layerControlElement.style.fontWeight = "500"
        layerControlElement.style.boxShadow = "0 2px 10px rgba(0,0,0,0.1)"

        // Mejorar el estilo de los labels
        const labels = layerControlElement.querySelectorAll("label")
        labels.forEach((label: any) => {
          label.style.display = "flex"
          label.style.alignItems = "center"
          label.style.marginBottom = "8px"
          label.style.cursor = "pointer"
          label.style.padding = "4px"
          label.style.borderRadius = "4px"
          label.style.transition = "background-color 0.2s"

          label.addEventListener("mouseenter", () => {
            label.style.backgroundColor = "#f3f4f6"
          })
          label.addEventListener("mouseleave", () => {
            label.style.backgroundColor = "transparent"
          })
        })
      }
    }, 100)

    // Agregar leyenda mejorada
    const legend = leaflet.control({ position: "bottomright" })
    legend.onAdd = () => {
      const div = leaflet.DomUtil.create("div", "info legend")
      div.style.backgroundColor = "rgba(255, 255, 255, 0.95)"
      div.style.padding = "12px"
      div.style.border = "2px solid #ccc"
      div.style.borderRadius = "8px"
      div.style.fontSize = "14px"
      div.style.boxShadow = "0 2px 10px rgba(0,0,0,0.1)"
      div.innerHTML = `
        <h4 style="margin: 0 0 10px 0; font-weight: 600; color: #374151;">${razonSocial}</h4>
        <div style="margin-bottom: 6px;"><span style="color: #22c55e; font-size: 16px;">■</span> <span style="margin-left: 8px;">Propiedades Propias (${propiosData.length})</span></div>
        <div><span style="color: #f97316; font-size: 16px;">■</span> <span style="margin-left: 8px;">Propiedades Alquiladas (${alquiladosData.length})</span></div>
      `
      return div
    }
    legend.addTo(mapInstance)

    // Guardar referencias
    setMap(mapInstance)
    setPropiosLayers(propiosLayersArray)
    setAlquiladosLayers(alquiladosLayersArray)

    // Cleanup
    return () => {
      mapInstance.remove()
    }
  }, [
    mapLoaded,
    leaflet,
    coordenadasPropios,
    coordenadasAlquilados,
    centroidePropiosLat,
    centroidePropiosLng,
    centroideAlquiladosLat,
    centroideAlquiladosLng,
    razonSocial,
  ])

  // Aplicar filtros cuando cambia polygonFilter
  useEffect(() => {
    if (!map) return

    propiosLayers.forEach((layer) => {
      if (polygonFilter === "todos" || polygonFilter === "propios") {
        if (!map.hasLayer(layer)) {
          map.addLayer(layer)
        }
      } else {
        if (map.hasLayer(layer)) {
          map.removeLayer(layer)
        }
      }
    })

    alquiladosLayers.forEach((layer) => {
      if (polygonFilter === "todos" || polygonFilter === "alquilados") {
        if (!map.hasLayer(layer)) {
          map.addLayer(layer)
        }
      } else {
        if (map.hasLayer(layer)) {
          map.removeLayer(layer)
        }
      }
    })
  }, [polygonFilter, map, propiosLayers, alquiladosLayers])

  // Escuchar eventos de descarga KML - MEJORADO
  useEffect(() => {
    const handleDownloadKML = (event: any) => {
      console.log("🎯 Evento de descarga recibido:", event.detail)
      const { type } = event.detail

      let kml = ""
      let filename = ""

      try {
        switch (type) {
          case "propios":
            console.log("📁 Generando KML para propios:", propiosData.length, "polígonos")
            if (propiosData.length === 0) {
              alert("❌ No hay polígonos propios para descargar")
              return
            }
            kml = generateKML(propiosData, "Propias", razonSocial, cuit)
            filename = `${cuit}_${razonSocial.replace(/\s+/g, "_")}_Propias.kml`
            break
          case "alquilados":
            console.log("📁 Generando KML para alquilados:", alquiladosData.length, "polígonos")
            if (alquiladosData.length === 0) {
              alert("❌ No hay polígonos alquilados para descargar")
              return
            }
            kml = generateKML(alquiladosData, "Alquiladas", razonSocial, cuit)
            filename = `${cuit}_${razonSocial.replace(/\s+/g, "_")}_Alquiladas.kml`
            break
          case "todos":
            console.log("📁 Generando KML para todos:", propiosData.length + alquiladosData.length, "polígonos")
            const allData = [...propiosData, ...alquiladosData]
            if (allData.length === 0) {
              alert("❌ No hay polígonos para descargar")
              return
            }
            kml = generateKML(allData, "Todas", razonSocial, cuit)
            filename = `${cuit}_${razonSocial.replace(/\s+/g, "_")}_Todas.kml`
            break
        }

        if (kml && kml.length > 100) {
          console.log("✅ KML generado correctamente, iniciando descarga...")
          console.log("📄 Contenido KML:", kml.substring(0, 200) + "...")

          const success = downloadFile(kml, filename, "application/vnd.google-earth.kml+xml")

          if (success) {
            alert(
              `✅ Descarga iniciada: ${filename}\n\n💡 Si no se descarga automáticamente, verifica que tu navegador permita descargas automáticas.`,
            )
          } else {
            // Ofrecer descarga manual como último recurso
            const userWantsManual = confirm(
              `❌ La descarga automática falló.\n\n¿Quieres copiar el contenido KML al portapapeles para guardarlo manualmente?`,
            )

            if (userWantsManual) {
              try {
                navigator.clipboard
                  .writeText(kml)
                  .then(() => {
                    alert(
                      `📋 Contenido KML copiado al portapapeles.\n\nPega el contenido en un archivo de texto y guárdalo como: ${filename}`,
                    )
                  })
                  .catch(() => {
                    // Fallback para navegadores sin clipboard API
                    const textArea = document.createElement("textarea")
                    textArea.value = kml
                    document.body.appendChild(textArea)
                    textArea.select()
                    document.execCommand("copy")
                    document.body.removeChild(textArea)
                    alert(
                      `📋 Contenido KML copiado al portapapeles.\n\nPega el contenido en un archivo de texto y guárdalo como: ${filename}`,
                    )
                  })
              } catch (clipboardError) {
                console.error("Error al copiar al portapapeles:", clipboardError)
                alert(
                  `❌ No se pudo copiar al portapapeles.\n\nRevisa la consola del navegador para ver el contenido KML.`,
                )
                console.log("📄 CONTENIDO KML PARA COPIAR MANUALMENTE:")
                console.log(kml)
              }
            }
          }
        } else {
          console.error("❌ KML vacío o inválido")
          alert("❌ Error: No se pudo generar el archivo KML")
        }
      } catch (error) {
        console.error("💥 Error en descarga KML:", error)
        alert(`❌ Error al generar el archivo KML: ${error.message}`)
      }
    }

    window.addEventListener("downloadKML", handleDownloadKML)
    return () => window.removeEventListener("downloadKML", handleDownloadKML)
  }, [propiosData, alquiladosData, razonSocial, cuit])

  if (!mapLoaded) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-100 rounded-lg">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-2"></div>
          <p className="text-sm text-gray-600">Cargando mapa...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="relative h-full w-full">
      <div id="mapa-geojson" className="h-full w-full rounded-lg"></div>
    </div>
  )
}
