"use client"
import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

/*
 * Para evitar que el bundle falle en Next Lite (no incluye Leaflet por defecto),
 * cargamos la librería de mapas sólo si existe `window`.
 * De momento mostramos un placeholder; puede reemplazarse por un mapa real.
 */

interface Props {
  data: any
  selectedCUIT: string
}

export function MapasPropiedades({ data, selectedCUIT }: Props) {
  const [ready, setReady] = useState(false)

  useEffect(() => {
    if (typeof window !== "undefined") {
      setReady(true)
    }
  }, [])

  if (!ready) {
    return <p className="text-sm text-gray-500">Cargando mapa…</p>
  }

  const productor = data?.general.find((p: any) => p.CUIT === selectedCUIT)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Mapa de Propiedades</CardTitle>
      </CardHeader>
      <CardContent>
        {productor ? (
          <div className="h-64 flex items-center justify-center rounded-md border bg-gray-100 text-gray-500">
            {/* Aquí se integraría un mapa (Leaflet, Mapbox, etc.) con los GeoJSON:
                productor.GeoJSON_Propios y productor.GeoJSON_Alquilados */}
            Vista de mapa próximamente
          </div>
        ) : (
          <p className="text-sm text-gray-500">No se encontró el productor seleccionado.</p>
        )}
      </CardContent>
    </Card>
  )
}
