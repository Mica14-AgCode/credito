"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Download, Eye } from "lucide-react"

interface MapaActivosProps {
  coordenadasPropios: string
  centroidePropiosLat: number
  centroidePropiosLng: number
  razonSocial: string
  cuit: string
  valorTierras: number
  hectareasValuadas: number
}

// ──────────────────────────────────────────────────────────
// Convierte una celda CSV en un array de objetos válidos
function parseGeoJsonCell(cell: string): any[] {
  // Normalizar y descartar valores vacíos o de tipo "N/D"
  const trimmed = (cell ?? "").trim()
  if (
    !trimmed || // cadena vacía
    trimmed.toUpperCase() === "N/D" || // marcador "No Disponible"
    trimmed.toUpperCase() === "ND" // variación corta
  ) {
    return []
  }

  // Si la celda no empieza con "{" o "[" asumimos que NO es JSON
  const firstChar = trimmed[0]
  if (firstChar !== "{" && firstChar !== "[") {
    return []
  }

  // 1) Limpieza básica
  let cleaned = trimmed
    .replace(/\\"/g, '"') // \"  -> "
    .replace(/\\n/g, "") // quita saltos escapados
    .replace(/\uFEFF/g, "") // quita BOM
    .trim()

  // 2) Primer intento: JSON válido
  try {
    return JSON.parse(cleaned)
  } catch (_) {
    /* vazio – intentaremos reparar */
  }

  // 3) Intento de reparación:
  //    a) comillas simples → dobles
  //    b) agrega comillas a las claves sin comillas  {tipo: ...} -> {"tipo": ...}
  cleaned = cleaned.replace(/'/g, '"').replace(/([{,]\s*)([A-Za-z_][A-Za-z0-9_]*)\s*:/g, '$1"$2":')

  // c) agrega comillas a los valores string sin comillas  : Polygon → : "Polygon"
  cleaned = cleaned.replace(/:\s*([A-Za-z_][A-Za-z0-9_]*)\s*([,}])/g, (_m, val, tail) => {
    const lower = val.toLowerCase()
    // deja pasar true, false, null y números
    if (["true", "false", "null"].includes(lower) || /^\d+(\.\d+)?$/.test(val)) {
      return `: ${val}${tail}`
    }
    return `: "${val}"${tail}`
  })

  try {
    return JSON.parse(cleaned)
  } catch (err) {
    console.error("GeoJSON malformado irreparable:", err, cleaned.slice(0, 120) + "…")
    return []
  }
}

// Función para generar KML
function generateKML(polygons: any[], razonSocial: string, cuit: string): string {
  if (!polygons || polygons.length === 0) {
    console.warn("No hay polígonos para generar KML")
    return ""
  }

  const kmlHeader = `<?xml version="1.0" encoding="UTF-8"?>
<kml xmlns="http://www.opengis.net/kml/2.2">
  <Document>
    <name>${razonSocial} - Campos Propios</name>
    <description>Propiedades de ${razonSocial} (CUIT: ${cuit})</description>`

  const kmlFooter = `  </Document>
</kml>`

  const placemarks = polygons
    .map((polygon, index) => {
      if (!polygon.coordenadas || !Array.isArray(polygon.coordenadas)) {
        console.warn(`Polígono ${index} no tiene coordenadas válidas`)
        return ""
      }

      const coordinates = polygon.coordenadas
        .map((coord: number[]) => {
          if (!Array.isArray(coord) || coord.length < 2) return ""
          return `${coord[0]},${coord[1]},0`
        })
        .filter(Boolean)
        .join(" ")

      if (!coordinates) {
        console.warn(`Polígono ${index} no tiene coordenadas procesables`)
        return ""
      }

      return `    <Placemark>
      <name>Campo Propio ${index + 1}</name>
      <description>Polígono ${index + 1} - ${razonSocial}</description>
      <Polygon>
        <outerBoundaryIs>
          <LinearRing>
            <coordinates>${coordinates}</coordinates>
          </LinearRing>
        </outerBoundaryIs>
      </Polygon>
    </Placemark>`
    })
    .filter(Boolean)
    .join("\n")

  return `${kmlHeader}\n${placemarks}\n${kmlFooter}`
}

// Función para descargar archivo
function downloadFile(content: string, filename: string, mimeType: string) {
  if (!content) {
    console.error("No hay contenido para descargar")
    return false
  }

  try {
    const blob = new Blob([content], { type: mimeType })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = filename
    link.style.display = "none"
    document.body.appendChild(link)
    link.click()
    setTimeout(() => {
      document.body.removeChild(link)
      URL.revokeObjectURL(url)
    }, 100)
    console.log(`✅ Descarga iniciada: ${filename}`)
    return true
  } catch (error) {
    console.error("Error al descargar archivo:", error)
    return false
  }
}

export default function MapaActivos({
  coordenadasPropios,
  centroidePropiosLat,
  centroidePropiosLng,
  razonSocial,
  cuit,
  valorTierras,
  hectareasValuadas,
}: MapaActivosProps) {
  const [mapLoaded, setMapLoaded] = useState(false)
  const [leaflet, setLeaflet] = useState<any>(null)
  const [map, setMap] = useState<any>(null)
  const [propiosLayers, setPropiosLayers] = useState<any[]>([])
  const [opacidad, setOpacidad] = useState([0.6])

  // Datos parseados
  const propiosData = parseGeoJsonCell(coordenadasPropios)

  console.log("📊 Datos parseados ACTIVOS:", {
    propios: propiosData.length,
    centroide: { lat: centroidePropiosLat, lng: centroidePropiosLng },
    coordenadasRaw: coordenadasPropios?.slice(0, 100) + "...",
  })

  useEffect(() => {
    // Cargar Leaflet dinámicamente solo en el cliente
    const loadLeaflet = async () => {
      try {
        const L = await import("leaflet")
        await import("leaflet/dist/leaflet.css")

        // Fix para los iconos de Leaflet
        delete (L.Icon.Default.prototype as any)._getIconUrl
        L.Icon.Default.mergeOptions({
          iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
          iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
          shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
        })

        setLeaflet(L)
        setMapLoaded(true)
      } catch (error) {
        console.error("Error cargando Leaflet:", error)
      }
    }

    if (typeof window !== "undefined") {
      loadLeaflet()
    }
  }, [])

  useEffect(() => {
    if (!mapLoaded || !leaflet) return

    // COORDENADAS ESPECÍFICAS PARA BUENOS AIRES RURAL
    let centerLat = -35.5 // Zona rural Buenos Aires
    let centerLng = -59.5
    let zoomLevel = 11

    // Si tenemos centroide válido Y no es 0,0, usarlo
    if (
      centroidePropiosLat &&
      centroidePropiosLng &&
      centroidePropiosLat !== 0 &&
      centroidePropiosLng !== 0 &&
      Math.abs(centroidePropiosLat) > 1 &&
      Math.abs(centroidePropiosLng) > 1
    ) {
      centerLat = centroidePropiosLat
      centerLng = centroidePropiosLng
      zoomLevel = 13
      console.log("🎯 Usando centroide válido:", { lat: centerLat, lng: centerLng })
    }

    // Si hay datos de polígonos, calcular centro
    if (propiosData.length > 0 && propiosData[0].coordenadas && propiosData[0].coordenadas.length > 0) {
      const firstPolygon = propiosData[0].coordenadas
      if (firstPolygon.length > 0 && Array.isArray(firstPolygon[0]) && firstPolygon[0].length >= 2) {
        const sumLat = firstPolygon.reduce((sum: number, coord: number[]) => sum + coord[1], 0)
        const sumLng = firstPolygon.reduce((sum: number, coord: number[]) => sum + coord[0], 0)
        centerLat = sumLat / firstPolygon.length
        centerLng = sumLng / firstPolygon.length
        zoomLevel = 14
        console.log("🎯 Centro calculado del polígono:", { lat: centerLat, lng: centerLng })
      }
    }

    console.log("🗺️ Creando mapa en:", { lat: centerLat, lng: centerLng, zoom: zoomLevel })

    // ANTES
    //const mapInstance = leaflet.map("mapa-activos").setView([centerLat, centerLng], zoomLevel)
    // AHORA  –  sin animaciones que requieren _leaflet_pos
    const mapInstance = leaflet
      .map("mapa-activos", {
        zoomControl: true,
        zoomAnimation: false,
        fadeAnimation: false,
        markerZoomAnimation: false,
      })
      .setView([centerLat, centerLng], zoomLevel)

    // Definir capas base
    const osmLayer = leaflet.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors",
    })

    const satelliteLayer = leaflet.tileLayer(
      "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
      {
        attribution: "© Esri, Maxar, Earthstar Geographics",
      },
    )

    // Agregar capa base inicial
    osmLayer.addTo(mapInstance)

    // Crear polígonos propios
    const propiosLayersArray: any[] = []
    propiosData.forEach((poligono: any, index: number) => {
      if (poligono.coordenadas && poligono.coordenadas.length > 0) {
        try {
          const leafletCoords = poligono.coordenadas.map((coord: number[]) => [coord[1], coord[0]])

          const layer = leaflet
            .polygon(leafletCoords, {
              fillColor: "#22c55e",
              weight: 3,
              opacity: 1,
              color: "#16a34a",
              fillOpacity: opacidad[0],
            })
            .bindPopup(`
                <strong>Campo Propio ${index + 1}</strong><br/>
                <strong>${razonSocial}</strong><br/>
                Tipo: Propiedad Propia<br/>
                Valor Tierras: $${valorTierras.toLocaleString()}<br/>
                Ha Valuadas: ${hectareasValuadas.toFixed(1)} ha
              `)

          layer.addTo(mapInstance)
          propiosLayersArray.push(layer)
          console.log(`✅ Polígono ${index + 1} agregado con ${leafletCoords.length} coordenadas`)
        } catch (error) {
          console.error(`❌ Error agregando polígono ${index + 1}:`, error)
        }
      }
    })

    // Ajustar vista a los polígonos cuando el mapa esté listo
    mapInstance.whenReady(() => {
      try {
        // Asegura que el contenedor haya calculado su tamaño real
        mapInstance.invalidateSize()

        if (propiosLayersArray.length > 0) {
          const group = leaflet.featureGroup(propiosLayersArray)
          const bounds = group.getBounds()
          if (bounds.isValid()) {
            mapInstance.fitBounds(bounds, { padding: [20, 20], animate: false })
            console.log("🎯 Vista ajustada a los polígonos (whenReady)")
          }
        }
      } catch (error) {
        console.error("Error ajustando vista (whenReady):", error)
      }
    })

    // AJUSTAR VISTA A LOS POLÍGONOS
    /*
    if (propiosLayersArray.length > 0) {
      setTimeout(() => {
        try {
          const group = leaflet.featureGroup(propiosLayersArray)
          const bounds = group.getBounds()
          if (bounds.isValid()) {
            mapInstance.fitBounds(bounds, { padding: [20, 20] })
            console.log("🎯 Vista ajustada a los polígonos")
          }
        } catch (error) {
          console.error("Error ajustando vista:", error)
        }
      }, 500)
    }
    */

    // Control de capas
    const baseLayers = {
      "🗺️ Estándar": osmLayer,
      "🛰️ Satelital": satelliteLayer,
    }

    leaflet.control.layers(baseLayers, {}, { position: "topright" }).addTo(mapInstance)

    // Leyenda
    const legend = leaflet.control({ position: "bottomright" })
    legend.onAdd = () => {
      const div = leaflet.DomUtil.create("div", "info legend")
      div.style.backgroundColor = "rgba(255, 255, 255, 0.95)"
      div.style.padding = "12px"
      div.style.border = "2px solid #ccc"
      div.style.borderRadius = "8px"
      div.style.fontSize = "14px"
      div.style.boxShadow = "0 2px 10px rgba(0,0,0,0.1)"
      div.innerHTML = `
        <h4 style="margin: 0 0 10px 0; font-weight: 600; color: #374151;">Activos - ${razonSocial}</h4>
        <div style="margin-bottom: 6px;"><span style="color: #22c55e; font-size: 16px;">■</span> <span style="margin-left: 8px;">Campos Propios (${propiosData.length})</span></div>
        <hr style="margin: 8px 0;">
        <div style="font-size: 12px; color: #6b7280;">
          <div>Valor Tierras: $${valorTierras.toLocaleString()}</div>
          <div>Ha Valuadas: ${hectareasValuadas.toFixed(1)} ha</div>
        </div>
      `
      return div
    }
    legend.addTo(mapInstance)

    // Guardar referencias
    setMap(mapInstance)
    setPropiosLayers(propiosLayersArray)

    // Cleanup
    return () => {
      mapInstance.remove()
    }
  }, [
    mapLoaded,
    leaflet,
    coordenadasPropios,
    centroidePropiosLat,
    centroidePropiosLng,
    razonSocial,
    valorTierras,
    hectareasValuadas,
  ])

  // Actualizar opacidad cuando cambia el slider
  useEffect(() => {
    if (propiosLayers.length > 0) {
      propiosLayers.forEach((layer) => {
        layer.setStyle({ fillOpacity: opacidad[0] })
      })
    }
  }, [opacidad, propiosLayers])

  const handleDownloadKMZ = () => {
    console.log("🎯 Descargando KML...")
    if (propiosData.length === 0) {
      alert("❌ No hay polígonos para descargar")
      return
    }

    const kml = generateKML(propiosData, razonSocial, cuit)
    const filename = `${cuit}_${razonSocial.replace(/\s+/g, "_")}_Campos_Propios.kml`

    if (kml && downloadFile(kml, filename, "application/vnd.google-earth.kml+xml")) {
      alert(`✅ Descarga iniciada: ${filename}`)
    } else {
      alert("❌ Error al generar el archivo KML")
    }
  }

  if (!mapLoaded) {
    return (
      <div className="h-96 flex items-center justify-center bg-gray-100 rounded-lg">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600 mx-auto mb-2"></div>
          <p className="text-sm text-gray-600">Cargando mapa de activos...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {/* Controles del mapa */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between p-4 bg-gray-50 rounded-lg">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Eye className="h-4 w-4 text-gray-600" />
            <label className="text-sm font-medium">Opacidad:</label>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-500">0%</span>
            <Slider value={opacidad} onValueChange={setOpacidad} max={1} min={0} step={0.1} className="w-32" />
            <span className="text-sm text-gray-500">100%</span>
          </div>
          <span className="text-sm font-medium">{Math.round(opacidad[0] * 100)}%</span>
        </div>

        <Button onClick={handleDownloadKMZ} className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Descargar KMZ
        </Button>
      </div>

      {/* Mapa */}
      <div id="mapa-activos" className="h-96 w-full rounded-lg border-2 border-gray-200"></div>
    </div>
  )
}
